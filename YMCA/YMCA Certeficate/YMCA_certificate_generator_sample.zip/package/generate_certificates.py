#!/usr/bin/env python3
"""Generate personalized YMCA certificates from Certified.pdf and participant CSVs.

CSV files are expected to contain one participant name per line (no header).
For the current sample run, use --limit 3.
"""
from __future__ import annotations

import argparse
import csv
import re
import uuid
from pathlib import Path
from io import BytesIO

import qrcode
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader

PAGE_W, PAGE_H = 842, 595

# Coordinates are PDF points, origin at bottom-left.
# Tuned against the supplied one-page A4 landscape template.
NAME_CENTER_X = 430
NAME_BASELINE_Y = 350
NAME_MAX_WIDTH = 535
NAME_MAX_SIZE = 27
NAME_MIN_SIZE = 17

COURSE_CENTER_X = 430
COURSE_BASELINE_Y = 172
COURSE_MAX_WIDTH = 360
COURSE_MAX_SIZE = 17
COURSE_MIN_SIZE = 11

# QR sits in the lower-right white area, clear of the two signatures/date.
QR_X = 730
QR_Y = 205
QR_SIZE = 55

DEFAULT_VERIFY_BASE = "https://verify.example.org/c"


def slug_course(filename: str) -> str:
    name = filename.lower()
    name = re.sub(r"^certified[-_ ]*", "", name)
    name = re.sub(r"\.csv$", "", name)
    name = name.strip(" _-")
    aliases = {
        "digital marketing": "Digital Marketing",
        "french": "French",
        "personal leadership": "Personal Leadership",
        "project mgt": "Project Management",
        "project management": "Project Management",
        "spanish": "Spanish",
        "chinees": "Chinese",
        "chinese": "Chinese",
        "english": "English",
        "it&ai": "IT & AI",
        "it & ai": "IT & AI",
    }
    return aliases.get(name, name.title())


def fit_font(text: str, font: str, max_size: float, min_size: float, max_width: float) -> float:
    size = max_size
    while size > min_size and pdfmetrics.stringWidth(text, font, size) > max_width:
        size -= 0.5
    return max(size, min_size)


def clean_name(name: str) -> str:
    return " ".join(name.strip().split())


def read_participants(input_dir: Path):
    rows = []
    seen = set()
    duplicates = []
    for csv_path in sorted(input_dir.glob("*.csv")):
        course = slug_course(csv_path.name)
        with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
            for line_no, line in enumerate(f, 1):
                name = clean_name(line)
                if not name:
                    continue
                # Skip obvious non-person placeholder entries.
                if name.lower() in {"morning class"}:
                    continue
                key = (name.casefold(), course.casefold())
                if key in seen:
                    duplicates.append((name, course, csv_path.name, line_no))
                    continue
                seen.add(key)
                rows.append({"name": name, "course": course})
    return rows, duplicates


def make_qr(url: str) -> BytesIO:
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=8,
        border=2,
    )
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return buf


def create_overlay(name: str, course: str, certificate_id: str, verify_base: str, font_path: Path) -> BytesIO:
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H))

    pdfmetrics.registerFont(TTFont("CertSans", str(font_path)))
    pdfmetrics.registerFont(TTFont("CertSansBold", str(font_path.parent / "DejaVuSans-Bold.ttf")))

    # Participant name: centered, bold, real PDF text (not outlined/rasterized).
    size = fit_font(name, "CertSansBold", NAME_MAX_SIZE, NAME_MIN_SIZE, NAME_MAX_WIDTH)
    c.setFont("CertSansBold", size)
    c.setFillColorRGB(0.04, 0.09, 0.16)
    c.drawCentredString(NAME_CENTER_X, NAME_BASELINE_Y, name)

    # Course: centered below the existing "PROGRAMME / COURSE COMPLETED" label.
    course_size = fit_font(course, "CertSansBold", COURSE_MAX_SIZE, COURSE_MIN_SIZE, COURSE_MAX_WIDTH)
    c.setFont("CertSansBold", course_size)
    c.setFillColorRGB(0.04, 0.09, 0.16)
    c.drawCentredString(COURSE_CENTER_X, COURSE_BASELINE_Y, course)

    # QR: only encodes an opaque certificate verification URL.
    url = f"{verify_base.rstrip('/')}/{certificate_id}"
    qr_buf = make_qr(url)
    c.drawImage(ImageReader(qr_buf), QR_X, QR_Y, width=QR_SIZE, height=QR_SIZE, preserveAspectRatio=True, mask="auto")

    c.save()
    buf.seek(0)
    return buf


def merge(template: Path, overlay: BytesIO, output: Path):
    base = PdfReader(str(template))
    over = PdfReader(overlay)
    page = base.pages[0]
    page.merge_page(over.pages[0])
    writer = PdfWriter()
    writer.add_page(page)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as f:
        writer.write(f)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--template", type=Path, default=Path("Certified.pdf"))
    parser.add_argument("--participants", type=Path, default=Path("certified_participants"))
    parser.add_argument("--output", type=Path, default=Path("generated_certificates"))
    parser.add_argument("--limit", type=int, default=3, help="Generate only the first N certificates; 0 means all")
    parser.add_argument("--verify-base", default=DEFAULT_VERIFY_BASE)
    default_font = Path(__file__).resolve().parent / "fonts" / "DejaVuSans.ttf"
    parser.add_argument("--font", type=Path, default=default_font)
    args = parser.parse_args()

    if not args.template.exists():
        raise SystemExit(f"Template not found: {args.template}")
    if not args.participants.exists():
        raise SystemExit(f"Participant directory not found: {args.participants}")

    rows, duplicates = read_participants(args.participants)
    selected = rows if args.limit == 0 else rows[:args.limit]

    registry_path = args.output / "certificate_registry.csv"
    args.output.mkdir(parents=True, exist_ok=True)

    with registry_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["certificate_id", "participant_name", "course", "verification_url", "status"])
        writer.writeheader()
        for row in selected:
            cert_id = str(uuid.uuid4())
            verify_url = f"{args.verify_base.rstrip('/')}/{cert_id}"
            safe_name = re.sub(r"[^A-Za-z0-9._ -]+", "", row["name"]).strip().replace(" ", "_") or "participant"
            safe_course = re.sub(r"[^A-Za-z0-9& -]+", "", row["course"]).strip().replace(" ", "_")
            output_file = args.output / safe_course / f"{safe_name}.pdf"
            overlay = create_overlay(row["name"], row["course"], cert_id, args.verify_base, args.font)
            merge(args.template, overlay, output_file)
            writer.writerow({
                "certificate_id": cert_id,
                "participant_name": row["name"],
                "course": row["course"],
                "verification_url": verify_url,
                "status": "valid",
            })
            print(f"Generated: {output_file}")

    if duplicates:
        dup_path = args.output / "duplicates_report.csv"
        with dup_path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["name", "course", "source_file", "line"])
            writer.writerows(duplicates)
        print(f"Duplicate records reported: {dup_path}")

    print(f"Generated {len(selected)} certificate(s). Registry: {registry_path}")


if __name__ == "__main__":
    main()
